### Telegram Smart App Demo

[Тестовый бот](https://t.me/smart_app_demo_bot)
