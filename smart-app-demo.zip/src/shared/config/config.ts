/**
 * @description Domain of the external API
 * @example https://api.mysite.com
 */
export const EXTERNAL_API_DOMAIN = process.env.EXTERNAL_API_DOMAIN